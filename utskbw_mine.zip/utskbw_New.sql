-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 24, 2024 at 01:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `utskbw`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `inf` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `des` varchar(240) NOT NULL,
  `nem` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `inf`, `skill`, `des`, `nem`) VALUES
(1, 'I\'m an Informatics student with an interest in websites and a strong desire to learn new things. I have a variety of skills and experience in the field of design.', 'I have skills in graphic design and photography, but I lack experience with ', 'I\'m a student from Pembangunan Jaya University', 'Aliffa Zhafira');

-- --------------------------------------------------------

--
-- Table structure for table `act`
--

CREATE TABLE `act` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `wkt` varchar(255) NOT NULL,
  `ket` varchar(240) NOT NULL,
  `tit1` varchar(255) NOT NULL,
  `tit2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `act`
--

INSERT INTO `act` (`id`, `judul`, `wkt`, `ket`, `tit1`, `tit2`) VALUES
(1, 'Ethnictanz', 'Dec 2023 - Present', 'Member of Ethnictanz, Traditional Dance in Pembangunan Jaya University', 'Conducting the process of documenting news and photos of activities.Conducting the process of documenting news and photos of activities.', 'Responsible for socialization and external communication.');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `your_name` varchar(255) NOT NULL,
  `your_email` varchar(255) NOT NULL,
  `subjek` varchar(255) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `your_name`, `your_email`, `subjek`, `pesan`) VALUES
(1, 'test', 'test', 'test', 'test'),
(4, 'test', 'test@gmail.com', 'hilmi', 'hilmi'),
(5, 'test', 'test@gmail.com', 'hilmi123', 'hilmi123'),
(9, 'anomali', 'anomali@gmail.com', 'hi', 'selamat malam');

-- --------------------------------------------------------

--
-- Table structure for table `Journey`
--

CREATE TABLE `Journey` (
  `id` int(11) NOT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `Institution_Organization` varchar(100) DEFAULT NULL,
  `Start_Date` varchar(20) DEFAULT NULL,
  `End_Date` varchar(20) DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Journey`
--

INSERT INTO `Journey` (`id`, `Category`, `Title`, `Institution_Organization`, `Start_Date`, `End_Date`, `Description`) VALUES
(1, 'Education', 'Vocational School Multimedia', 'Waskito School', '2020', '2023', 'I studied for six years at Waskito, and I learned design, photography, and PHP websites in the last three years.'),
(2, 'Education', 'Middle School', 'Waskito School', '2017', '2020', 'I studied for three years at Waskito High School.'),
(3, 'Experience', 'Ethnictanz', 'Pembangunan Jaya University', 'Dec 2023', 'Present', 'Member of Ethnictanz, Traditional Dance in Pembangunan Jaya University. Conducting the process of documenting news and photos of activities. Responsible for socialization and external communication.'),
(4, 'Experience', 'Part of Himaforka', 'Kominfo Department (Public Relations)', 'Aug 2023', 'Present', 'Arrange company\'s attendance at public events. Communicate with media. Research public expectations and demands.');

-- --------------------------------------------------------

--
-- Table structure for table `pict`
--

CREATE TABLE `pict` (
  `id` int(11) NOT NULL,
  `education` varchar(255) NOT NULL,
  `edu` varchar(255) NOT NULL,
  `expe` varchar(240) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pict`
--

INSERT INTO `pict` (`id`, `education`, `edu`, `expe`) VALUES
(1, 'I studied for six years at Waskito, and I learn design, photography and php websites on the las three years.', 'I studied for three years in Waskito High School.', '');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `title`, `image`, `description`, `category`) VALUES
(1, 'Banner', 'assets/img/ban.png', 'My Design when I was an intern in Solideo School.', 'Design'),
(2, 'Flat Design', 'assets/img/flat.jpg', 'My Design when I was a student at Waskito School.', 'Design'),
(3, 'Brochure', 'assets/img/brosur.png', 'My Design when I was a student at Waskito School.', 'Design');

-- --------------------------------------------------------

--
-- Table structure for table `porto`
--

CREATE TABLE `porto` (
  `id` int(11) NOT NULL,
  `abt` varchar(255) NOT NULL,
  `mine` varchar(255) NOT NULL,
  `info` varchar(255) DEFAULT NULL,
  `skill` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `porto`
--

INSERT INTO `porto` (`id`, `abt`, `mine`, `info`, `skill`) VALUES
(1, 'Hai! I\'m Aliffa Zhafira 💖', 'I\'m a student from Pembangunan Jaya University and right now I\'m majoring in Informatics', NULL, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Journey`
--
ALTER TABLE `Journey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Journey`
--
ALTER TABLE `Journey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
